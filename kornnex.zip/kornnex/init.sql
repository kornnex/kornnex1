DROP DATABASE IF EXISTS kornnex_db;
CREATE DATABASE kornnex_db;
\c kornnex_db;

CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    email VARCHAR(150) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL
);

CREATE TABLE businesses (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    name VARCHAR(255) DEFAULT 'Mi Emprendimiento',
    description TEXT DEFAULT 'Descripción de mi negocio',
    category VARCHAR(100) DEFAULT 'General',
    location VARCHAR(255) DEFAULT 'Alejandro Korn',
    phone VARCHAR(50),
    instagram VARCHAR(100),
    profile_pic VARCHAR(255),
    cover_pic VARCHAR(255),
    edits_count INTEGER DEFAULT 0,
    subscription_active_until TIMESTAMP,
    featured_until TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE products (
    id SERIAL PRIMARY KEY,
    business_id INTEGER REFERENCES businesses(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    stock INTEGER NOT NULL,
    image VARCHAR(255)
);

CREATE TABLE logs (
    id SERIAL PRIMARY KEY,
    action TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE messages (
    id SERIAL PRIMARY KEY,
    sender_id INTEGER NOT NULL, 
    business_id INTEGER,
    message TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);