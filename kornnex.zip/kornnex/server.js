const express = require('express');
const { Pool } = require('pg');
const multer = require('multer');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const path = require('path');
const { MercadoPagoConfig, Preference } = require('mercadopago');

const app = express();
app.use(express.json());
app.use(express.static('public'));

// ================= CONFIGURACIONES =================
const pool = new Pool({
    user: 'postgres',
    host: 'localhost',
    database: 'kornnex_db',
    password: '1234', // PON TU CLAVE REAL DE POSTGRES AQUÍ
    port: 5432,
});

// Mercado Pago Config (Reemplaza con tu ACCESS TOKEN de producción/prueba)
const mpAccessToken = 'TEST-TU-ACCESS-TOKEN-AQUI';
const client = new MercadoPagoConfig({ accessToken: mpAccessToken });

const storage = multer.diskStorage({
    destination: (req, file, cb) => cb(null, 'public/uploads/'),
    filename: (req, file, cb) => cb(null, Date.now() + path.extname(file.originalname))
});
const upload = multer({ storage: storage });

const JWT_SECRET = 'kornnex_secreto_super_seguro';

// ================= MIDDLEWARES =================
const authenticate = (req, res, next) => {
    const token = req.headers.authorization;
    if (!token) return res.status(401).json({ error: 'No autorizado' });
    try {
        const decoded = jwt.verify(token.split(" ")[1], JWT_SECRET);
        req.user = decoded;
        next();
    } catch (e) {
        res.status(401).json({ error: 'Token inválido' });
    }
};

const adminAuth = (req, res, next) => {
    const user = req.headers.admin_user;
    const pass = req.headers.admin_pass;
    if (user === '94904173' && pass === 'bancoballenavoley') next();
    else res.status(401).json({ error: 'Credenciales de Admin Incorrectas' });
};

const logAction = async (action) => {
    await pool.query('INSERT INTO logs (action) VALUES ($1)', [action]);
};

// ================= RUTAS DE AUTENTICACIÓN =================
app.post('/api/register', async (req, res) => {
    const { email, password } = req.body;
    try {
        const hash = await bcrypt.hash(password, 10);
        const result = await pool.query(
            'INSERT INTO users (email, password) VALUES ($1, $2) RETURNING id',
            [email, hash]
        );
        const userId = result.rows[0].id;
        
        await pool.query('INSERT INTO businesses (user_id) VALUES ($1)', [userId]);
        await logAction(`Nuevo usuario registrado: ${email}`);
        
        res.json({ message: 'Registrado con éxito' });
    } catch (error) {
        res.status(400).json({ error: 'El email ya está en uso o hubo un error' });
    }
});

app.post('/api/login', async (req, res) => {
    const { email, password } = req.body;
    try {
        const result = await pool.query('SELECT * FROM users WHERE email = $1', [email]);
        if (result.rows.length === 0) return res.status(400).json({ error: 'Email no encontrado' });
        
        const user = result.rows[0];
        const valid = await bcrypt.compare(password, user.password);
        if (!valid) return res.status(400).json({ error: 'Contraseña incorrecta' });
        
        const token = jwt.sign({ id: user.id, email: user.email }, JWT_SECRET);
        res.json({ token });
    } catch (error) {
        res.status(500).json({ error: 'Error del servidor' });
    }
});

// ================= RUTAS DEL COMERCIANTE (DASHBOARD) =================
app.get('/api/my_business', authenticate, async (req, res) => {
    try {
        const bResult = await pool.query('SELECT * FROM businesses WHERE user_id = $1', [req.user.id]);
        const business = bResult.rows[0];
        const pResult = await pool.query('SELECT * FROM products WHERE business_id = $1', [business.id]);
        res.json({ business, products: pResult.rows });
    } catch (error) {
        res.status(500).json({ error: 'Error al cargar negocio' });
    }
});

app.post('/api/update_business', authenticate, upload.fields([{ name: 'profile_pic' }, { name: 'cover_pic' }]), async (req, res) => {
    try {
        const { name, description, category, location, phone, instagram } = req.body;
        const bResult = await pool.query('SELECT * FROM businesses WHERE user_id = $1', [req.user.id]);
        const business = bResult.rows[0];

        const isSubscribed = business.subscription_active_until && new Date(business.subscription_active_until) > new Date();
        if (business.edits_count >= 1 && !isSubscribed) {
            return res.status(403).json({ error: 'Prueba gratuita agotada. Debes pagar el plan mensual.' });
        }

        let profilePath = business.profile_pic;
        let coverPath = business.cover_pic;
        if (req.files['profile_pic']) profilePath = '/uploads/' + req.files['profile_pic'][0].filename;
        if (req.files['cover_pic']) coverPath = '/uploads/' + req.files['cover_pic'][0].filename;

        await pool.query(
            `UPDATE businesses SET name = $1, description = $2, category = $3, location = $4, 
             phone = $5, instagram = $6, profile_pic = $7, cover_pic = $8, edits_count = edits_count + 1 
             WHERE user_id = $9`,
            [name, description, category, location, phone, instagram, profilePath, coverPath, req.user.id]
        );

        await logAction(`Usuario modificado: ${name}`);
        res.json({ message: 'Negocio actualizado correctamente' });
    } catch (error) {
        res.status(500).json({ error: 'Error al actualizar negocio' });
    }
});

app.post('/api/products', authenticate, upload.single('image'), async (req, res) => {
    try {
        const { name, price, stock } = req.body;
        const bResult = await pool.query('SELECT id FROM businesses WHERE user_id = $1', [req.user.id]);
        const businessId = bResult.rows[0].id;
        const imagePath = req.file ? '/uploads/' + req.file.filename : null;

        await pool.query(
            'INSERT INTO products (business_id, name, price, stock, image) VALUES ($1, $2, $3, $4, $5)',
            [businessId, name, price, stock, imagePath]
        );
        res.json({ message: 'Producto agregado' });
    } catch (error) {
        res.status(500).json({ error: 'Error al agregar producto' });
    }
});

// ================= MERCADO PAGO =================
app.post('/api/pay', authenticate, async (req, res) => {
    const { type } = req.body; 
    let title = '';
    let price = 0;

    if (mpAccessToken === 'TEST-TU-ACCESS-TOKEN-AQUI') {
        return res.status(400).json({ error: "No configuraste el Token de Mercado Pago en el archivo server.js" });
    }

    if (type === 'ad') { title = 'Anuncio Destacado (1 Semana)'; price = 2000; }
    else if (type === 'subscription') { title = 'Suscripción Edición (1 Mes)'; price = 5000; }
    else return res.status(400).json({ error: 'Tipo inválido' });

    try {
        const preference = new Preference(client);
        const response = await preference.create({
            body: {
                items: [{ title, unit_price: price, quantity: 1, currency_id: 'ARS' }],
                back_urls: {
                    success: `http://localhost:3000/api/pay/success?type=${type}&userId=${req.user.id}`,
                    failure: 'http://localhost:3000/dashboard.html',
                    pending: 'http://localhost:3000/dashboard.html'
                },
                auto_return: 'approved'
            }
        });
        res.json({ init_point: response.init_point });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Error creando la preferencia en Mercado Pago. Verifica tu Token.' });
    }
});

app.get('/api/pay/success', async (req, res) => {
    const { type, userId } = req.query;
    try {
        if (type === 'ad') {
            await pool.query(`UPDATE businesses SET featured_until = NOW() + INTERVAL '7 days' WHERE user_id = $1`, [userId]);
            await logAction(`El usuario ID ${userId} compró: Anuncio`);
        } else if (type === 'subscription') {
            await pool.query(`UPDATE businesses SET subscription_active_until = NOW() + INTERVAL '1 month' WHERE user_id = $1`, [userId]);
            await logAction(`El usuario ID ${userId} compró: Suscripción Edición`);
        }
        res.redirect('/dashboard.html?payment=success');
    } catch (error) {
        res.status(500).send('Error procesando pago');
    }
});

// ================= BUSCADOR PRINCIPAL =================
app.get('/api/search', async (req, res) => {
    const query = req.query.q || '';
    try {
        let result;
        if (query.trim() === '') {
            result = await pool.query(`
                SELECT b.*, (CASE WHEN b.featured_until > NOW() THEN 1 ELSE 0 END) as is_featured
                FROM businesses b ORDER BY is_featured DESC, created_at DESC
            `);
        } else {
            const searchTerm = `%${query}%`;
            result = await pool.query(`
                SELECT DISTINCT b.*, (CASE WHEN b.featured_until > NOW() THEN 1 ELSE 0 END) as is_featured
                FROM businesses b LEFT JOIN products p ON p.business_id = b.id
                WHERE b.name ILIKE $1 OR b.category ILIKE $1 OR b.location ILIKE $1 
                OR b.description ILIKE $1 OR p.name ILIKE $1
                ORDER BY is_featured DESC, b.name ASC
            `, [searchTerm]);
        }
        res.json(result.rows);
    } catch (error) { res.status(500).json({ error: 'Error en el buscador' }); }
});

app.get('/api/business/:id', async (req, res) => {
    const { id } = req.params;
    try {
        const bResult = await pool.query('SELECT * FROM businesses WHERE id = $1', [id]);
        const pResult = await pool.query('SELECT * FROM products WHERE business_id = $1', [id]);
        res.json({ business: bResult.rows[0], products: pResult.rows });
    } catch (error) { res.status(500).json({ error: 'Error' }); }
});

// ================= CHAT Y ADMIN =================
app.post('/api/chat', authenticate, async (req, res) => {
    const { message } = req.body;
    try {
        const bResult = await pool.query('SELECT id FROM businesses WHERE user_id = $1', [req.user.id]);
        await pool.query('INSERT INTO messages (sender_id, business_id, message) VALUES ($1, $2, $3)', [req.user.id, bResult.rows[0].id, message]);
        res.json({ message: 'Enviado' });
    } catch (e) { res.status(500).json({ error: 'Error en chat' }); }
});

app.get('/api/chat', authenticate, async (req, res) => {
    try {
        const bResult = await pool.query('SELECT id FROM businesses WHERE user_id = $1', [req.user.id]);
        const msgs = await pool.query('SELECT * FROM messages WHERE business_id = $1 ORDER BY created_at ASC', [bResult.rows[0].id]);
        res.json(msgs.rows);
    } catch (e) { res.status(500).json({ error: 'Error en chat' }); }
});

app.get('/api/admin/data', adminAuth, async (req, res) => {
    try {
        const businesses = await pool.query(`
            SELECT b.*, u.email FROM businesses b JOIN users u ON b.user_id = u.id ORDER BY b.id ASC
        `);
        const logs = await pool.query('SELECT * FROM logs ORDER BY created_at DESC LIMIT 50');
        const msgs = await pool.query(`
            SELECT m.*, b.name as business_name FROM messages m 
            JOIN businesses b ON m.business_id = b.id ORDER BY m.created_at DESC LIMIT 50
        `);
        res.json({ businesses: businesses.rows, logs: logs.rows, messages: msgs.rows });
    } catch (e) { res.status(500).json({ error: 'Error cargando data de admin' }); }
});

app.delete('/api/admin/business/:id', adminAuth, async (req, res) => {
    try {
        await pool.query('DELETE FROM businesses WHERE id = $1', [req.params.id]);
        await logAction(`Admin eliminó el negocio ID ${req.params.id}`);
        res.json({ message: 'Eliminado' });
    } catch (e) { res.status(500).json({ error: 'Error' }); }
});

app.put('/api/admin/business/:id/featured', adminAuth, async (req, res) => {
    try {
        await pool.query(`UPDATE businesses SET featured_until = NOW() + INTERVAL '7 days' WHERE id = $1`, [req.params.id]);
        await logAction(`Admin destacó el negocio ID ${req.params.id}`);
        res.json({ message: 'Destacado' });
    } catch (e) { res.status(500).json({ error: 'Error' }); }
});

app.post('/api/admin/chat', adminAuth, async (req, res) => {
    const { business_id, message } = req.body;
    try {
        await pool.query('INSERT INTO messages (sender_id, business_id, message) VALUES (0, $1, $2)', [business_id, message]);
        res.json({ message: 'Enviado' });
    } catch (e) { res.status(500).json({ error: 'Error en chat admin' }); }
});

const PORT = 3000;
app.listen(PORT, () => console.log(`Kornnex ejecutándose en el puerto ${PORT}`));